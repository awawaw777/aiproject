"""ЛабТехника. Рахимов Никита Алексеевич, ИСП44-9. Python 3.9+."""
import csv
import io
import sqlite3
from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_DB = ROOT / 'labtech.db'
STATUSES = ('В эксплуатации', 'На складе', 'В ремонте', 'Списано')

def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')

def required(value, label, limit=1000):
    text = str(value).strip()
    if not text or len(text) > limit:
        raise ValueError(f'{label}: заполните поле (не более {limit} символов)')
    return text

class Inventory:
    def __init__(self, path=DEFAULT_DB):
        path = Path(path).resolve()
        if not path.is_file():
            raise ValueError('База данных не найдена. Восстановите копию или выполните init_db.py для новой базы.')
        self.conn = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys=ON')

    def close(self):
        self.conn.close()

    def rows(self, query, args=()):
        return [dict(r) for r in self.conn.execute(query, args)]

    def audit(self, action, details):
        self.conn.execute('INSERT INTO audit(created_at,action,details) VALUES(?,?,?)', (now(), action, details))

    def reference(self, table):
        if table not in ('categories','rooms','employees'):
            raise ValueError('Неизвестный справочник')
        return self.rows(f'SELECT * FROM {table} ORDER BY id')

    def add_reference(self, table, name):
        if table not in ('categories','rooms','employees'):
            raise ValueError('Неизвестный справочник')
        with self.conn:
            result = self.conn.execute(f'INSERT INTO {table}(name) VALUES(?)', (required(name,'Название',120),))
            self.audit('Справочник', f'{table}: {name}')
        return result.lastrowid

    def list_equipment(self, search='', status=''):
        rows = self.rows('''SELECT e.*, c.name category, r.name room, p.name employee
            FROM equipment e JOIN categories c ON c.id=e.category_id
            JOIN rooms r ON r.id=e.room_id JOIN employees p ON p.id=e.employee_id
            ORDER BY e.inventory''')
        q = search.casefold().strip()
        return [r for r in rows if (not status or r['status']==status) and
                (not q or q in ' '.join(str(r[k]) for k in ('inventory','serial','title','room','employee')).casefold())]

    def get(self, equipment_id):
        row = self.conn.execute('SELECT * FROM equipment WHERE id=?',(int(equipment_id),)).fetchone()
        if row is None:
            raise ValueError('Оборудование не найдено')
        return dict(row)

    def add_equipment(self, inventory, serial, title, category_id, room_id, employee_id,
                      purchase_date, cost, notes='', status='В эксплуатации'):
        inventory = required(inventory,'Инвентарный номер',40)
        serial = required(serial,'Серийный номер',80)
        title = required(title,'Наименование',160)
        if status not in ('В эксплуатации','На складе'):
            raise ValueError('Начальный статус: В эксплуатации или На складе')
        parsed = date.fromisoformat(purchase_date)
        if parsed > date.today():
            raise ValueError('Дата приобретения не может быть в будущем')
        try:
            amount = Decimal(str(cost).replace(',','.'))
            if not amount.is_finite() or amount<0 or amount>Decimal('100000000') or amount*100 != (amount*100).to_integral_value():
                raise ValueError('Стоимость: от 0 до 100000000 рублей, не более двух знаков после запятой')
        except InvalidOperation:
            raise ValueError('Стоимость должна быть числом') from None
        if len(notes)>2000:
            raise ValueError('Характеристики: не более 2000 символов')
        with self.conn:
            cur = self.conn.execute('''INSERT INTO equipment(inventory,serial,title,category_id,room_id,
                employee_id,purchase_date,cost_kopecks,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?)''',
                (inventory,serial,title,int(category_id),int(room_id),int(employee_id),parsed.isoformat(),int(amount*100),status,notes))
            self.audit('Регистрация',inventory)
        return cur.lastrowid

    def move(self, equipment_id, room_id, employee_id, reason):
        reason = required(reason,'Основание',500)
        with self.conn:
            row = self.get(equipment_id)
            if row['status'] in ('Списано','В ремонте'):
                raise ValueError('Нельзя переместить списанную технику или технику в ремонте')
            if (row['room_id'],row['employee_id'])==(int(room_id),int(employee_id)):
                raise ValueError('Кабинет и ответственное лицо не изменились')
            self.conn.execute('''INSERT INTO movements(equipment_id,old_room,new_room,old_employee,new_employee,created_at,reason)
                VALUES(?,?,?,?,?,?,?)''',(row['id'],row['room_id'],int(room_id),row['employee_id'],int(employee_id),now(),reason))
            self.conn.execute('UPDATE equipment SET room_id=?,employee_id=? WHERE id=?',(int(room_id),int(employee_id),row['id']))
            self.audit('Перемещение',f"{row['inventory']}: {reason}")

    def open_ticket(self, equipment_id, description, engineer):
        description = required(description,'Описание',1000)
        engineer = required(engineer,'Исполнитель',120)
        with self.conn:
            row = self.get(equipment_id)
            if row['status'] in ('Списано','В ремонте'):
                raise ValueError('Техника списана или уже находится в ремонте')
            cur = self.conn.execute('''INSERT INTO tickets(equipment_id,description,engineer,created_at,status)
                VALUES(?,?,?,?,'Открыта')''',(row['id'],description,engineer,now()))
            self.conn.execute("UPDATE equipment SET status='В ремонте' WHERE id=?",(row['id'],))
            self.audit('Заявка открыта',f"{row['inventory']}: {description}")
        return cur.lastrowid

    def close_ticket(self, ticket_id, resolution, status='В эксплуатации'):
        resolution = required(resolution,'Результат ремонта',1000)
        if status not in ('В эксплуатации','На складе'):
            raise ValueError('Выберите статус после ремонта')
        with self.conn:
            row = self.conn.execute('SELECT * FROM tickets WHERE id=?',(int(ticket_id),)).fetchone()
            if row is None or row['status']!='Открыта':
                raise ValueError('Открытая заявка не найдена')
            self.conn.execute("UPDATE tickets SET status='Выполнена',closed_at=?,resolution=? WHERE id=?",(now(),resolution,row['id']))
            self.conn.execute('UPDATE equipment SET status=? WHERE id=?',(status,row['equipment_id']))
            self.audit('Заявка закрыта',f'{ticket_id}: {resolution}')

    def retire(self, equipment_id, reason):
        reason = required(reason,'Основание списания',500)
        with self.conn:
            row = self.get(equipment_id)
            if row['status'] in ('В ремонте','Списано'):
                raise ValueError('Завершите ремонт; повторное списание запрещено')
            self.conn.execute("UPDATE equipment SET status='Списано' WHERE id=?",(row['id'],))
            self.audit('Списание',f"{row['inventory']}: {reason}")

    def tickets(self):
        return self.rows('''SELECT t.*,e.inventory FROM tickets t JOIN equipment e ON e.id=t.equipment_id ORDER BY t.id DESC''')

    def movements(self):
        return self.rows('''SELECT m.*, e.inventory, r1.name old_room_name,r2.name new_room_name,
            p1.name old_employee_name,p2.name new_employee_name FROM movements m
            JOIN equipment e ON e.id=m.equipment_id JOIN rooms r1 ON r1.id=m.old_room
            JOIN rooms r2 ON r2.id=m.new_room JOIN employees p1 ON p1.id=m.old_employee
            JOIN employees p2 ON p2.id=m.new_employee ORDER BY m.id DESC''')

    def csv(self, search='',status=''):
        output=io.StringIO(newline='')
        writer=csv.writer(output,delimiter=';')
        writer.writerow(['Инвентарный номер','Серийный номер','Наименование','Категория','Кабинет','Ответственный','Дата покупки','Стоимость, руб.','Статус'])
        def safe(v):
            s=str(v)
            return "'"+s if s.lstrip().startswith(('=','+','-','@','\t','\r')) else s
        for r in self.list_equipment(search,status):
            writer.writerow([safe(r[k]) for k in ('inventory','serial','title','category','room','employee','purchase_date')]+[f"{r['cost_kopecks']/100:.2f}".replace('.',','),r['status']])
        return ('\ufeff'+output.getvalue()).encode('utf-8')
