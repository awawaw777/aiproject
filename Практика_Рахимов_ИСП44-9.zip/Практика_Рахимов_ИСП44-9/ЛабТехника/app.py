"""Локальный веб-интерфейс ИС ЛабТехника. Запуск: python app.py."""
import argparse
import html
import secrets
import sqlite3
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlsplit
from core import Inventory, DEFAULT_DB, STATUSES

TOKEN = secrets.token_urlsafe(32)
def esc(value):
    return html.escape(str(value),quote=True)

def inp(name,label,kind='text',value='',optional=False):
    return f'<label>{esc(label)}<input name="{esc(name)}" type="{kind}" value="{esc(value)}" {"" if optional else "required"}></label>'

def select(name,label,items):
    options=''.join(f'<option value="{esc(k)}">{esc(v)}</option>' for k,v in items)
    return f'<label>{esc(label)}<select name="{name}">{options}</select></label>'

def form(action,body,button):
    return f'<form method="post" action="/{action}"><input type="hidden" name="token" value="{TOKEN}">{body}<button>{button}</button></form>'

def table(headers,rows):
    states = {'В эксплуатации':'green', 'Выполнена':'green',
              'В ремонте':'amber', 'Открыта':'amber', 'На складе':'gray', 'Списано':'gray'}
    def cell(value, heading):
        text = str(value) if value is not None else '—'
        style = ''
        if heading in ('Дата','Открыта','Завершена') and value:
            try:
                text = datetime.fromisoformat(str(value)).strftime('%d.%m.%Y %H:%M')
                style = ' class="date-cell"'
            except ValueError:
                pass
        if heading in ('№','Код','Инв. номер','Стоимость, ₽'):
            style = ' class="number-cell"'
        rendered = esc(text)
        if heading == 'Статус' and text in states:
            rendered = f'<span class="status {states[text]}">{rendered}</span>'
        return f'<td{style}>{rendered}</td>'
    head = ''.join('<th scope="col">'+esc(h)+'</th>' for h in headers)
    body = ''.join('<tr>'+''.join(cell(v,h) for h,v in zip(headers,row))+'</tr>' for row in rows)
    if not body:
        body = f'<tr><td class="empty" colspan="{len(headers)}">Записей пока нет</td></tr>'
    return '<div class="scroll" tabindex="0" role="region" aria-label="Таблица данных"><table><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>'

CSS = r'''*{box-sizing:border-box}
:root{--ink:#242d2a;--muted:#6e7974;--line:#e2e7e3;--accent:#2f6753;--soft:#edf4ef;--surface:#fff}
body{margin:0;background:#f6f7f5;color:var(--ink);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased}
a{color:inherit}button,input,select{font:inherit}button,a,input,select,summary{ -webkit-tap-highlight-color:transparent}
:focus-visible{outline:3px solid #9bc0ad;outline-offset:3px}
header{background:var(--surface);border-bottom:1px solid var(--line)}
.topbar{max-width:1320px;margin:auto;padding:23px 32px;display:flex;align-items:center;justify-content:space-between;gap:24px}
.brand{display:flex;align-items:center;gap:13px;text-decoration:none}
.brandmark{width:40px;height:40px;display:grid;place-items:center;background:var(--soft);border-radius:11px;color:var(--accent)}
.brandmark svg{width:23px;height:23px}h1{font-size:19px;line-height:1.2;letter-spacing:-.5px;margin:0;font-weight:650}
.brand p{font-size:12px;color:var(--muted);margin:3px 0 0}.workspace-label{color:var(--muted);font-size:12px}
main{max-width:1320px;margin:auto;padding:30px 32px 20px}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:0 0 28px;background:var(--surface);border:1px solid var(--line);border-radius:12px}
.stat{padding:20px 25px;position:relative}.stat+.stat:before{content:"";position:absolute;top:22px;bottom:22px;left:0;border-left:1px solid var(--line)}
.stat strong{display:block;font-size:30px;font-weight:550;letter-spacing:-1px;line-height:1.2;font-variant-numeric:tabular-nums}
.stat span{display:flex;align-items:center;gap:7px;font-size:12px;margin-top:6px;color:var(--muted)}
.stat:nth-child(2) span:before,.stat:nth-child(3) span:before,.stat:nth-child(4) span:before{content:"";height:5px;width:5px;border-radius:50%;background:#729982}
.stat:nth-child(3) span:before{background:#c29a58}.stat:nth-child(4) span:before{background:#97a09a}
nav{display:flex;gap:28px;overflow-x:auto;border-bottom:1px solid #dce2dd;margin-bottom:30px;scrollbar-width:thin}
nav a{position:relative;white-space:nowrap;text-decoration:none;padding:0 0 14px;color:var(--muted);font-size:13px;font-weight:500}
nav a:hover{color:var(--ink)}nav a.active{color:var(--accent)}nav a.active:after{content:"";height:2px;background:var(--accent);position:absolute;bottom:0;left:0;right:0;border-radius:2px}
h2{font-size:24px;font-weight:600;line-height:1.3;letter-spacing:-.65px;margin:0 0 7px}h3{font-size:16px;font-weight:600;margin:26px 0 12px}
.intro{color:var(--muted);font-size:13px;margin:0 0 22px;max-width:800px}
.scroll{overflow-x:auto;border:1px solid var(--line);border-radius:10px;background:var(--surface);scrollbar-width:thin}
table{width:100%;border-collapse:collapse;font-size:13px;text-align:left}
th,td{padding:14px 16px;border-bottom:1px solid #ebeeeb;vertical-align:middle}
th{background:#fafbf9;color:#748078;font-size:11px;letter-spacing:.12px;font-weight:550;white-space:nowrap}
tbody tr:last-child td{border-bottom:0}tbody tr:hover{background:#fafcf9}
td:nth-child(2){font-weight:500}.number-cell,.date-cell{white-space:nowrap;font-variant-numeric:tabular-nums}.number-cell{font-size:12px}.date-cell{font-size:12px;color:var(--muted)}
.empty{text-align:center;padding:40px;color:var(--muted)}
.status{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;font-size:11px;line-height:1.5;padding:4px 9px;border-radius:5px;font-weight:450}
.status:before{content:"";width:4px;height:4px;border-radius:50%;background:currentColor}.status.green{color:#39684d;background:#edf4ed}.status.amber{color:#8d6a32;background:#f8f2e7}.status.gray{color:#68736b;background:#f0f2ef}
form{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:18px;align-items:end;background:var(--surface);padding:22px;border:1px solid var(--line);border-radius:10px;margin:18px 0 24px}
form.filter-form{grid-template-columns:minmax(180px,1fr) 200px auto auto;gap:12px;padding:0;background:transparent;border:0;margin:22px 0 18px}
label{display:flex;flex-direction:column;gap:7px;min-width:0;font-size:12px;color:#657169}
input,select{height:40px;width:100%;padding:9px 11px;border:1px solid #d9dfd9;border-radius:6px;background:white;color:var(--ink);font-size:13px;outline:none;transition:border-color .12s}
input:hover,select:hover{border-color:#aebfb2}input:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px #2f675310}
button,.button{display:inline-flex;justify-content:center;align-items:center;gap:8px;min-height:40px;padding:9px 17px;border:1px solid var(--accent);border-radius:6px;background:var(--accent);color:white;font-size:12px;font-weight:500;cursor:pointer;text-decoration:none;transition:background .12s;white-space:nowrap}
button:hover,.button:hover{background:#245440}.button.secondary{background:white;color:#48574d;border-color:#d9dfd9}.button.secondary:hover{background:#edf2ed}.button svg{width:15px;height:15px}
form button{justify-self:start}form.filter-form button{justify-self:stretch}
.result-count{font-size:12px;color:var(--muted);margin:0 0 10px}
details{background:white;border:1px solid var(--line);border-radius:9px;margin-top:14px}
summary{display:flex;align-items:center;justify-content:space-between;cursor:pointer;list-style:none;padding:16px 19px;font-weight:500;font-size:13px}
summary::-webkit-details-marker{display:none}summary:after{content:"+";font-size:20px;font-weight:300;color:#809084;line-height:1}details[open]>summary:after{content:"−"}
details[open]>summary{border-bottom:1px solid var(--line)}details form{border:0;border-radius:0;margin:0;padding:20px}
details .scroll{border:0;border-radius:0 0 9px 9px}details:last-of-type summary{color:#74645a}
.notice{padding:13px 17px;background:#edf4ed;color:#365b42;border:1px solid #d9e7da;border-radius:7px;margin-bottom:20px;font-size:13px}.notice.error{background:#faf0ed;border-color:#edd9d2;color:#894c3b}
footer{display:flex;justify-content:space-between;gap:15px;margin:32px 0 0;padding:18px 0 0;border-top:1px solid var(--line);color:#858d87;font-size:11px}
.service-copy{max-width:860px;background:white;border:1px solid var(--line);padding:22px 28px;border-radius:10px;margin-top:20px}.service-copy p{color:#657169}.service-copy li{margin:13px 0;padding-left:6px}
code{font:12px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace;background:#eef2ed;border-radius:4px;padding:3px 6px;overflow-wrap:anywhere}
@media(min-width:1050px){form[action="/add"]{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:760px){.topbar{padding:18px 20px}.workspace-label{display:none}main{padding:24px 20px 16px}.stats{grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:23px}.stat{padding:17px 20px}.stat:nth-child(3),.stat:nth-child(4){border-top:1px solid var(--line)}.stat:nth-child(3):before{display:none}.stat strong{font-size:27px}nav{gap:23px;margin-bottom:24px}h2{font-size:22px}form.filter-form{grid-template-columns:1fr 1fr}form.filter-form label:first-of-type{grid-column:1/-1}form.filter-form .button{grid-column:1/-1}th,td{padding:13px 14px}form{grid-template-columns:1fr;padding:18px;gap:15px}form button{width:100%}footer{flex-wrap:wrap}.service-copy{padding:18px}.service-copy ol{padding-left:18px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
'''

def page(db,tab='inventory',query='',status='',message='',error=False):
    all_rows=db.list_equipment()
    tabs=[('inventory','Реестр'),('move','Перемещения'),('tickets','Ремонт и ТО'),('refs','Справочники'),('audit','Журнал'),('service','Обслуживание')]
    nav='<nav aria-label="Разделы системы">'+''.join(
        '<a class="'+('active' if key==tab else '')+'" href="/?tab='+key+'"'+
        (' aria-current="page"' if key==tab else '')+'>'+title+'</a>'
        for key,title in tabs)+'</nav>'
    stats='<div class="stats">'+''.join(f'<div class="stat"><strong>{value}</strong><span>{label}</span></div>' for label,value in [('Всего единиц',len(all_rows)),('В эксплуатации',sum(r['status']=='В эксплуатации' for r in all_rows)),('В ремонте',sum(r['status']=='В ремонте' for r in all_rows)),('На складе',sum(r['status']=='На складе' for r in all_rows))])+'</div>'
    equipment=[(r['id'],f"{r['inventory']} · {r['title']}") for r in all_rows]
    rooms=[(r['id'],r['name']) for r in db.reference('rooms')]
    employees=[(r['id'],r['name']) for r in db.reference('employees')]
    categories=[(r['id'],r['name']) for r in db.reference('categories')]
    body=''
    if tab=='inventory':
        filtered=db.list_equipment(query,status)
        body='<h2>Реестр оборудования</h2><p class="intro">Техника, кабинеты и ответственные — в одном списке.</p><form class="filter-form" method="get"><input type="hidden" name="tab" value="inventory">'+inp('q','Поиск',value=query,optional=True)+'<label>Статус<select name="status">'+''.join(f'<option {"selected" if s==status else ""} value="{esc(s)}">{esc(s or "Все")}</option>' for s in ('',)+STATUSES)+'</select></label><button>Найти</button><a class="button secondary" href="/export?'+urlencode({'q':query,'status':status})+'">Скачать CSV</a></form>'
        body+=f'<p class="result-count">Записей в списке: {len(filtered)}</p>'
        body+=table(['Инв. номер','Наименование','Категория','Кабинет','Ответственный','Стоимость, ₽','Статус'],[[r['inventory'],r['title'],r['category'],r['room'],r['employee'],f"{r['cost_kopecks']/100:,.2f}".replace(',',' ').replace('.',','),r['status']] for r in filtered])
        body+='<details><summary>Добавить оборудование</summary>'+form('add',inp('inventory','Инвентарный номер')+inp('serial','Серийный номер')+inp('title','Наименование')+select('category_id','Категория',categories)+select('room_id','Кабинет',rooms)+select('employee_id','Ответственный',employees)+inp('purchase_date','Дата приобретения','date')+inp('cost','Стоимость в рублях',value='0.00')+select('status','Начальный статус',[(s,s) for s in ('В эксплуатации','На складе')])+inp('notes','Характеристики',optional=True),'Сохранить')+'</details>'
        body+='<details><summary>Карточки и серийные номера</summary>'+table(['Инв. номер','Серийный номер','Дата приобретения','Характеристики'],[[r['inventory'],r['serial'],r['purchase_date'],r['notes']] for r in filtered])+'</details>'
        body+='<details><summary>Списание по акту</summary>'+form('retire',select('equipment_id','Оборудование',[(r['id'],r['inventory']) for r in all_rows if r['status'] not in ('В ремонте','Списано')])+inp('reason','Номер и дата акта'),'Списать')+'</details>'
    elif tab=='move':
        body='<h2>Внутренние перемещения</h2><p class="intro">Оформите передачу техники и проверьте историю закрепления.</p>'+form('move',select('equipment_id','Оборудование',equipment)+select('room_id','Новый кабинет',rooms)+select('employee_id','Новый ответственный',employees)+inp('reason','Основание перемещения'),'Оформить перемещение')
        body+=table(['Дата','Инв. номер','Откуда','Куда','Прежний ответственный','Новый ответственный','Основание'],[[r[k] for k in ('created_at','inventory','old_room_name','new_room_name','old_employee_name','new_employee_name','reason')] for r in db.movements()])
    elif tab=='tickets':
        tickets=db.tickets()
        body='<h2>Ремонт и обслуживание</h2><p class="intro">Открытые заявки, выполненные работы и состояние оборудования.</p>'+form('open',select('equipment_id','Оборудование',equipment)+inp('description','Неисправность или вид ТО')+inp('engineer','Исполнитель'),'Создать заявку')
        body+=table(['№','Инв. номер','Описание','Исполнитель','Статус','Результат','Открыта','Завершена'],[[r[k] for k in ('id','inventory','description','engineer','status','resolution','created_at','closed_at')] for r in tickets])
        active=[(r['id'],f"№ {r['id']} · {r['inventory']}") for r in tickets if r['status']=='Открыта']
        if active:
            body+='<h3>Завершение ремонта</h3>'+form('close',select('ticket_id','Открытая заявка',active)+inp('resolution','Выполненные работы')+select('status','Состояние после ремонта',[(s,s) for s in ('В эксплуатации','На складе')]),'Завершить ремонт')
    elif tab=='refs':
        body='<h2>Справочники</h2><p class="intro">Категории оборудования, помещения и ответственные лица.</p>'+form('reference',select('table','Справочник',[('categories','Категории'),('rooms','Кабинеты'),('employees','Ответственные лица')])+inp('name','Новое значение'),'Добавить')
        for key,label in [('categories','Категории'),('rooms','Кабинеты'),('employees','Ответственные лица')]:
            body+='<h3>'+label+'</h3>'+table(['Код','Название'],[[r['id'],r['name']] for r in db.reference(key)])
    elif tab=='audit':
        body='<h2>Журнал операций</h2><p class="intro">Последние 500 записей об изменениях в системе.</p>'+table(['№','Дата','Операция','Содержание'],[[r[k] for k in ('id','created_at','action','details')] for r in db.rows('SELECT * FROM audit ORDER BY id DESC LIMIT 500')])
    else:
        body='''<h2>Обслуживание системы</h2><p class="intro">Резервные копии, проверка базы и восстановление данных.</p><div class="service-copy"><p>Команды выполняются в терминале из каталога программы. Перед обслуживанием остановите приложение: Ctrl+C.</p><ol><li>Создать копию: <code>python backup.py</code>.</li><li>Проверить и обслужить базу: <code>python maintenance.py</code>.</li><li>Проверить восстановление в отдельный каталог: <code>python backup.py --restore backups/ИМЯ.zip --target restored</code>.</li><li>Проверить восстановленную БД: <code>python app.py --db restored/labtech.db --port 8001</code>.</li></ol><p>Результаты сохраняются в каталогах backups и reports. Подробный порядок восстановления приведён в README.md.</p></div>'''
    notice=f'<div class="notice {"error" if error else ""}">{esc(message)}</div>' if message else ''
    return ('''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ЛабТехника — учёт оборудования</title><style>'''+CSS+'''</style></head><body>
<header><div class="topbar"><a class="brand" href="/" aria-label="ЛабТехника — главная">
<span class="brandmark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 21h8m-4-5v5M7 8h4m-4 3h7"/></svg></span>
<div><h1>ЛабТехника</h1><p>Оборудование учебных лабораторий</p></div></a><span class="workspace-label">Учёт и обслуживание</span></div></header>
<main>'''+stats+nav+notice+body+'''<footer><span>ЛабТехника</span><span>Учёт оборудования техникума</span></footer></main></body></html>''')


class Handler(BaseHTTPRequestHandler):
    db_path=DEFAULT_DB
    def send(self,data,status=200,kind='text/html; charset=utf-8',filename=None):
        payload=data.encode('utf-8') if isinstance(data,str) else data
        self.send_response(status)
        self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        if filename:
            self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(payload)

    def allowed_host(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')

    def do_GET(self):
        if not self.allowed_host():
            return self.send('Недопустимый адрес',403)
        parsed=urlsplit(self.path)
        q={k:v[0] for k,v in parse_qs(parsed.query).items()}
        if parsed.path not in ('/','/export'):
            return self.send('Страница не найдена',404)
        db=Inventory(self.db_path)
        try:
            if parsed.path=='/export':
                return self.send(db.csv(q.get('q',''),q.get('status','')),kind='text/csv; charset=utf-8',filename='inventory.csv')
            self.send(page(db,q.get('tab','inventory'),q.get('q',''),q.get('status',''),q.get('message','')))
        finally:
            db.close()

    def do_POST(self):
        if not self.allowed_host():
            return self.send('Недопустимый адрес',403)
        origin=self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):
            return self.send('Недопустимый источник запроса',403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=16384:
                return self.send('Неверный размер запроса',400)
            values={k:v[0] for k,v in parse_qs(self.rfile.read(length).decode('utf-8'),keep_blank_values=True).items()}
        except (ValueError,UnicodeError):
            return self.send('Неверный запрос',400)
        if not secrets.compare_digest(values.pop('token',''),TOKEN):
            return self.send('Обновите страницу и повторите действие',403)
        db=Inventory(self.db_path)
        tab='inventory'
        try:
            action=urlsplit(self.path).path
            if action=='/add':
                db.add_equipment(**{k:values[k] for k in ('inventory','serial','title','category_id','room_id','employee_id','purchase_date','cost','notes','status')})
            elif action=='/move':
                tab='move'; db.move(values['equipment_id'],values['room_id'],values['employee_id'],values['reason'])
            elif action=='/open':
                tab='tickets'; db.open_ticket(values['equipment_id'],values['description'],values['engineer'])
            elif action=='/close':
                tab='tickets'; db.close_ticket(values['ticket_id'],values['resolution'],values['status'])
            elif action=='/retire':
                db.retire(values['equipment_id'],values['reason'])
            elif action=='/reference':
                tab='refs'; db.add_reference(values['table'],values['name'])
            else:
                return self.send('Операция не найдена',404)
            self.send_response(303)
            self.send_header('Location','/?'+urlencode({'tab':tab,'message':'Операция выполнена'}))
            self.send_header('Content-Length','0')
            self.end_headers()
        except (ValueError,KeyError,sqlite3.IntegrityError) as exc:
            message=str(exc)
            if isinstance(exc,sqlite3.IntegrityError):
                message='Запись уже существует или выбрано отсутствующее значение справочника. Проверьте номера и справочники.'
            self.send(page(db,tab,message=message,error=True),400)
        except sqlite3.OperationalError:
            self.send(page(db,tab,message='База недоступна или занята. Повторите операцию после завершения обслуживания.',error=True),503)
        finally:
            db.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',default=str(DEFAULT_DB))
    parser.add_argument('--port',type=int,default=8000)
    args=parser.parse_args()
    try:
        db=Inventory(args.db); db.list_equipment(); db.close()
        Handler.db_path=args.db
        server=HTTPServer(('127.0.0.1',args.port),Handler)
    except (ValueError,OSError,sqlite3.Error) as exc:
        parser.exit(1,f'Ошибка запуска: {exc}\n')
    print(f'ЛабТехника: http://127.0.0.1:{args.port} · Остановка: Ctrl+C',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
