"""Создание новой учебной БД. Существующая база не перезаписывается."""
import argparse
import sqlite3
from pathlib import Path
from core import Inventory, ROOT, DEFAULT_DB

def initialize(path=DEFAULT_DB):
    path=Path(path)
    with path.open('xb'):
        pass
    connection=sqlite3.connect(path)
    try:
        connection.executescript((ROOT/'schema.sql').read_text(encoding='utf-8'))
    finally:
        connection.close()
    db=Inventory(path)
    try:
        for name in ('Компьютер','Ноутбук','Проектор','МФУ','Сетевое оборудование'):
            db.add_reference('categories',name)
        for name in ('Лаборатория 201','Лаборатория 202','Кабинет 203','Склад'):
            db.add_reference('rooms',name)
        for name in ('Учебный сотрудник 1','Учебный сотрудник 2','Учебный сотрудник 3'):
            db.add_reference('employees',name)
        samples=[('Системный блок учебный',1,1,1,42000),('Системный блок учебный',1,1,1,42000),
                 ('Системный блок учебный',1,2,2,45000),('Системный блок учебный',1,2,2,45000),
                 ('Ноутбук преподавателя',2,1,1,65000),('Ноутбук резервный',2,4,3,60000),
                 ('Проектор мультимедийный',3,1,1,38000),('Проектор мультимедийный',3,2,2,38000),
                 ('МФУ лазерное',4,3,3,28000),('МФУ резервное',4,4,3,25000),
                 ('Коммутатор 24 порта',5,2,2,18000),('Маршрутизатор',5,3,3,12000)]
        for i,(title,cat,room,person,cost) in enumerate(samples,1):
            db.add_equipment(f'ЛТ-{i:03}',f'DEMO-{i:04}',title,cat,room,person,'2025-09-01',cost,
                'Учебная карточка', 'На складе' if room==4 else 'В эксплуатации')
        db.move(5,2,2,'Учебная накладная П-01')
        done=db.open_ticket(7,'Профилактическая очистка фильтра','Учебный инженер')
        db.close_ticket(done,'Фильтр очищен; изображение проверено')
        db.open_ticket(9,'Замятие бумаги при печати','Учебный инженер')
    finally:
        db.close()
    return path

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',default=str(DEFAULT_DB))
    args=parser.parse_args()
    try:
        print('Создана учебная база:',initialize(args.db))
    except FileExistsError:
        parser.exit(1,'База уже существует; файл оставлен без изменений.\n')
