"""Согласованная копия БД, SQL-дамп и программные файлы; безопасное восстановление."""
import argparse
import hashlib
import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from core import ROOT, DEFAULT_DB, now

def checksum(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def create_backup(db_path=DEFAULT_DB, output=None):
    source=Path(db_path).resolve()
    if not source.is_file():
        raise ValueError('Исходная БД не найдена')
    output=Path(output or ROOT/'backups'); output.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    archive=output/f'labtech_{stamp}.zip'
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        src=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True)
        snapshot=sqlite3.connect(tmp/'labtech.db')
        try:
            src.backup(snapshot)
            if snapshot.execute('PRAGMA integrity_check').fetchall()!=[('ok',)] or snapshot.execute('PRAGMA foreign_key_check').fetchall():
                raise ValueError('Копия не прошла проверку целостности')
            (tmp/'dump.sql').write_text('\n'.join(snapshot.iterdump())+'\n',encoding='utf-8')
        finally:
            snapshot.close(); src.close()
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            z.write(tmp/'labtech.db','labtech.db'); z.write(tmp/'dump.sql','dump.sql')
            for pattern in ('*.py','*.sql','*.md','*.bat','*.command'):
                for path in ROOT.glob(pattern):
                    z.write(path,path.name)
            reports=ROOT/'reports'
            if reports.is_dir():
                for path in reports.iterdir():
                    if path.is_file():
                        z.write(path,'reports/'+path.name)
    digest=checksum(archive)
    archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n',encoding='utf-8')
    record={'time':now(),'archive':archive.name,'sha256':digest,'integrity':'ok'}
    with (output/'manifest.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps(record,ensure_ascii=False)+'\n')
    return record

def restore(archive,target):
    archive=Path(archive); target=Path(target)
    expected=archive.with_suffix('.zip.sha256').read_text(encoding='utf-8').split()[0]
    if checksum(archive)!=expected:
        raise ValueError('Контрольная сумма архива не совпадает')
    if target.exists():
        raise ValueError('Каталог восстановления уже существует; выберите новый')
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise ValueError('ZIP-архив повреждён')
            # Восстанавливаем только БД; архив не может перезаписать произвольные пути.
            (tmp/'labtech.db').write_bytes(z.read('labtech.db'))
        c=sqlite3.connect((tmp/'labtech.db').as_uri()+'?mode=ro',uri=True)
        try:
            if c.execute('PRAGMA integrity_check').fetchall()!=[('ok',)] or c.execute('PRAGMA foreign_key_check').fetchall():
                raise ValueError('Восстановленная база повреждена')
            counts={t:c.execute(f'SELECT count(*) FROM {t}').fetchone()[0] for t in ('equipment','movements','tickets','audit')}
        finally:
            c.close()
        target.mkdir(parents=True)
        shutil.copy2(tmp/'labtech.db',target/'labtech.db')
        result={'time':now(),'archive':archive.name,'sha256':expected,'integrity':'ok','counts':counts}
        (target/'restore_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db',default=str(DEFAULT_DB)); p.add_argument('--out')
    p.add_argument('--restore'); p.add_argument('--target')
    a=p.parse_args()
    try:
        if a.restore:
            if not a.target:
                p.error('--restore требует --target')
            result=restore(a.restore,a.target)
        else:
            result=create_backup(a.db,a.out)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except (ValueError,OSError,sqlite3.Error,zipfile.BadZipFile,KeyError) as exc:
        p.exit(1,f'Ошибка: {exc}\n')
